import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface Task {
  id: number;
  title: string;
  description: string;
  status: 'pending' | 'completed';
}

const TaskList: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    // Here you would typically fetch tasks from an API
    // For this example, we'll use mock data
    const mockTasks: Task[] = [
      { id: 1, title: 'Task 1', description: 'Description 1', status: 'pending' },
      { id: 2, title: 'Task 2', description: 'Description 2', status: 'completed' },
    ];
    setTasks(mockTasks);
  }, []);

  const handleStatusChange = (id: number) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, status: task.status === 'pending' ? 'completed' : 'pending' } : task
    ));
  };

  const handleDelete = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <div className="task-list">
      <h2>Tasks</h2>
      <ul>
        {tasks.map(task => (
          <li key={task.id}>
            <h3>{task.title}</h3>
            <p>{task.description}</p>
            <p>Status: {task.status}</p>
            <button onClick={() => handleStatusChange(task.id)}>
              {task.status === 'pending' ? 'Mark Completed' : 'Mark Pending'}
            </button>
            <Link to={`/edit-task/${task.id}`}>Edit</Link>
            <button onClick={() => handleDelete(task.id)}>Delete</button>
          </li>
        ))}
      </ul>
      <Link to="/add-task">Add New Task</Link>
    </div>
  );
};

export default TaskList;


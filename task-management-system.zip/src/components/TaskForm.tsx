import React, { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';

interface TaskFormProps {
  id?: string;
}

const TaskForm: React.FC<TaskFormProps> = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const { id } = useParams<{ id: string }>();
  const history = useHistory();

  useEffect(() => {
    if (id) {
      // Here you would typically fetch the task data from an API
      // For this example, we'll use mock data
      setTitle(`Task ${id}`);
      setDescription(`Description for Task ${id}`);
    }
  }, [id]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically make an API call to save the task
    console.log('Saving task:', { title, description });
    history.push('/tasks');
  };

  return (
    <div className="task-form">
      <h2>{id ? 'Edit Task' : 'Add New Task'}</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Task Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Task Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <button type="submit">{id ? 'Update Task' : 'Add Task'}</button>
      </form>
    </div>
  );
};

export default TaskForm;

